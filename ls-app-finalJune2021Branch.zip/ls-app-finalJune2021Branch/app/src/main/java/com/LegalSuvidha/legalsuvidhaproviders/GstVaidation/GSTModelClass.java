package com.LegalSuvidha.legalsuvidhaproviders.GstVaidation;

public class GSTModelClass {

//    public Boolean getFlag(String gst) {
//
//        return flag;
//    }


}
